# Personal Webpage Project

This is a simple personal webpage created as part of a Cloud Computing lab project.
It is hosted on GitHub Pages.

## Objective
To design and host a personal webpage using GitHub Pages.

## Author
**Md. Jamal Uddin**
Email: jamalkhantalukder@gmail.com
GitHub: https://github.com/jamalkhantalukder-alt
